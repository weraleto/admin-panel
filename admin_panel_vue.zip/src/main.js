import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'
// import Paintable from 'vue-paintable'

Vue.use(VueRouter)
// Vue.use(Paintable)

import Auth from './components/Auth'
import Welcome from './components/Welcome'
import Quiz from './components/Quiz'
import CliBase from './components/CliBase'
import CliInfo from './components/CliInfo'

const router = new VueRouter({
  mode: 'history',
  base: __dirname,
  routes: [
    {path:'/', name:'auth', component: Auth},
    {path:'/welcome', name:'home', component: Welcome},
    {path:'/quiz', name:'quiz', component: Quiz},
    {path:'/base', name:'client-base', component: CliBase},
    // {path:'/client/:id', name:'client-info', component: CliInfo},
  ],
  scrollBehavior (to, from, savedPosition) {
    return { x: 0, y: 0 }
  }
})

new Vue({
  router,
  el: '#app',
  render: h => h(App),

})
